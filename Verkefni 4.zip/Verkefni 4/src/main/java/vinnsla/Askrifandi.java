package vinnsla;

public class Askrifandi {
    private String nafn;

    public Askrifandi(String nafn) {
        this.nafn = nafn;
    }

    public String getNafn() {
        return nafn;
    }

    public void setNafn(String nafn) {
        this.nafn = nafn;
    }
}