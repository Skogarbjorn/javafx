package objects;

public interface Block {
		void breakBlock();
}
