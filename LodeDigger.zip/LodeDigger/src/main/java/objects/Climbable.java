package objects;

public interface Climbable {
}
