package entities;

import org.example.lodedigger.Area;

public interface Entity {
    void move(Area.Direction direction);
}
