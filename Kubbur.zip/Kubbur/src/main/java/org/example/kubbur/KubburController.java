package org.example.kubbur;

import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import vinnsla.Kubbur;
import vinnsla.Stykki;

public class KubburController {
    @FXML
    private TextField input;
    @FXML
    private Label stig;
    @FXML
    private GridPane keypad;
    @FXML
    private Label gameStatus;
    private Kubbur gamer = new Kubbur(3,3);
    private int stigLota;
    private int counter=0;
    IntegerProperty counterProperty = new SimpleIntegerProperty();
    private int totalStig=0;

    public void initialize() {
        stig.textProperty().bind(Bindings.createStringBinding(() ->
                        String.valueOf(totalStig+stigLota),
                counterProperty));

        counterProperty.set(counter);

        gameStatus.textProperty().bind(Bindings.createStringBinding(() -> {
            if (counterProperty.get() == gamer.getNumber().length) return "Leik lokið";
            else return "Leikur í gangi";
        },counterProperty));
    }

    @FXML
    protected void onNyTala() {
        stigLota=5;
        keypad.setDisable(false);
        for (Node i : keypad.getChildren())
            if (!i.isDisable()) {
                removeMynd((Button) i);
            }
        }

    @FXML
    protected void onSetjaStykki(ActionEvent actionEvent) {
        Button reitur = (Button) actionEvent.getSource();
        int i = GridPane.getRowIndex(reitur);
        int j = GridPane.getColumnIndex(reitur);
        setjaMynd(gamer.getBordStykki(i, j), reitur);
        if (correctHandler(gamer.getBordStykki(i, j))) reitur.setDisable(true);
        else if (stigLota > 1) stigLota--;
    }

    @FXML
    private void setjaMynd(Stykki stykki, Button b) {
        b.getStyleClass().removeAll();
        b.getStyleClass().add(stykki.getNafn());
    }

    @FXML
    private void removeMynd(Button b) {
        b.getStyleClass().setAll("button");
    }

    private boolean correctHandler(Stykki stykki) {
        if (Integer.toString(stykki.getTala()).equals(input.getText())) {
            stig();
            keypad.setDisable(true);
            counterProperty.set(++counter);
            return true;
        }
        return false;
    }

    private void stig() {
        totalStig = Integer.parseInt(stig.getText());
    }
}
