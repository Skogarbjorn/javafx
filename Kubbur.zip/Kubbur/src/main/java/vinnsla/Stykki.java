package vinnsla;

public class Stykki {
    private String nafnAMynd;
    private int tala;
    private static int counter=0;

    public Stykki(String nafnAMynd) {
        this.nafnAMynd = nafnAMynd;
        this.tala = ++counter;
    }

    public String getNafn() {
        return nafnAMynd;
    }

    public int getTala() {
        return tala;
    }
}
